# DM Closing System™

Premium static MVP for GitHub Pages.

## Run
Open `index.html` locally or deploy the repository to GitHub Pages. No build step is required.

## Product logic
The current browser engine is intentionally transparent and heuristic. It separates observed signals from inferred signals and returns a singular next move, decision distance, momentum, friction and a do-not-send recommendation.

For production AI, move model calls to a server-side endpoint and keep API keys out of browser JavaScript. The UI can consume the same analysis shape.
